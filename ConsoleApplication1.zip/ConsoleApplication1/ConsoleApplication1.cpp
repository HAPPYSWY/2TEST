﻿// ConsoleApplication1.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
int main()
{
	printf("helloword");
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
//#define N 21000
//#include<stdio.h> 
//#include <math.h>

//int find(int a[], int n);
//int max(int a, int b);

//int max(int a, int b)
//{
//	if (a >= b)
//	{
//		return a;
//	}
//	else
//	{
//		return b;
//	}
//}


//int find(int a[], int n)
//{
//	int dp[N];
//	dp[0] = a[0];
//	int maxx = a[0];
//	for (int i = 1; i < n; i++)
//	{
//		dp[i] = max(dp[i - 1] + a[i], a[i]);
//		if (maxx < dp[i])
//		{
//			maxx = dp[i];
//		}
//	}
//	return maxx;
//}
//int main()
//{
//	int a[N], n;
//	printf("请输入个数:");
//	scanf_s("%d", &n);
//	printf("请输入数值:");
//	for (int i = 0; i < n; i++)
//		scanf_s("%d", &a[i]);
//	int maxx = find(a, n);
//	printf("结果为:");
//	printf("%d", maxx);
//	return 0;
//}