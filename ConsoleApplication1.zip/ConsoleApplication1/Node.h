#pragma once
class Node
{


};

int find(int a[], int n);
int max(int a, int b);


