#include "Node.h"
#define N 21000
#include<stdio.h> 
#include <math.h>



int max(int a, int b)
{
	if (a >= b)
	{
		return a;
	}
	else
	{
		return b;
	}
}


int find(int a[], int n)
{
	int dp[N];
	dp[0] = a[0];
	int maxx = a[0];
	for (int i = 1; i < n; i++)
	{
		dp[i] = max(dp[i - 1] + a[i], a[i]);
		if (maxx < dp[i])
		{
			maxx = dp[i];
		}
	}
	return maxx;
}
